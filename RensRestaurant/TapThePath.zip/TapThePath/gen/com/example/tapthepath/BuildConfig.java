/** Automatically generated file. DO NOT MODIFY */
package com.example.tapthepath;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}