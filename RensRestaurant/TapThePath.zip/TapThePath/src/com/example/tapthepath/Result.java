package com.example.tapthepath;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class Result extends Activity  {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.result);
		
		Intent nameko =getIntent();
		Intent score=getIntent();
		Intent click=getIntent();
		Intent status=getIntent();
		String name=score.getStringExtra("nameko");
		String totalscore=score.getStringExtra("totalscore");
		String totalclick=click.getStringExtra("totalclick");
		String fstatus=status.getStringExtra("status");
		
		TextView aname=(TextView)findViewById(R.id.textView2);
		TextView aclick=(TextView)findViewById(R.id.textView3);
		TextView ascore=(TextView)findViewById(R.id.textView4);
		TextView astatus=(TextView)findViewById(R.id.textView5);
		aname.setText("Name:"+name);
		aclick.setText("Total Clicked:"+totalclick);
		ascore.setText("Score:"+totalscore);
		astatus.setText("Status:"+fstatus);
		
		Button btnmain=(Button)findViewById(R.id.button1);
		
		btnmain.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				Intent play=new Intent(v.getContext(),Front.class);
				startActivityForResult(play,0);
				
			}
			
		});
}

}